HORIZON TRANSIT 0.9.1 - Rides and bus lines for Forza Horizon 2 (Azimuth)
=========================================================================================
Your festival. Your route. / Dein Festival. Deine Route.
One mod file, one phone (F9). Uber-style rides and bus lines with virtual passengers.

  - RIDES: 3 requests nearby, GPS to pickup and destination, passengers who talk,
    remember you and rate your driving. VIPs, business clients, weddings, day trips.
  - DOORS: a door really opens and closes with its sound when passengers get in and out.
  - BUS: 6 lines both ways with real stops, a timetable and stop announcements.
  - PHONE OR TABLET: three devices (phone, Edge, tablet), 7 designs.
  - COMPANY: reputation, company funds, shop, workday with a statement.
  - SOUND: speed warning tones, bus gong and stop bell, ride pings, payout chime.
  - TALK BACK: answer a passenger's question with B (keyboard) or LB+RB+D-pad down.
  - MAP: a dark map on the phone with the game's own roads, a preview of each ride and bus
    line before you take it. The mod builds it at start from your own game files (the pause
    menu's map picture and the game's road network); no extra file needed. A "Navi" zoom
    turns the map with your car, like the game's own navigation. Zooms glide, screens fade.

Source code: https://github.com/Flenkii/Horizon-Transit

No game files, no Azimuth, no FH2 Mod Platform and no FH2MP included. Never paste commands
into PowerShell to install a mod - anything like that is a scam.
Not supported by the FH2 Mod Platform author, the FH2MP team or the Azimuth developer.

Tested with: Azimuth 1.0.4, FH2 Mod Platform 2.9.0, FH2MP 1.4.1.


1. INSTALLATION
---------------
1. Install Azimuth and the FH2 Mod Platform (the FH2MP launcher brings it). Start the game once.
2. Copy the folder "fh2-mods" from this ZIP next to azimuth.exe:
     fh2-mods\TransportSim.dll   (all sounds are inside it)
3. With the FH2MP launcher: Pause > MODS > Installed mods > Horizon Transit >
   "Load when playing online" = On (FH2MP counts every start from its launcher as online).
4. Start the game, drive a few metres, press F9.

Door sounds: Sounds From The Lab (royalty-free). All other sounds are made by the mod's own script.

Uninstall: delete fh2-mods\TransportSim.dll (and the folder Azimuth\TransportSim if you like).
Horizon Transit never changes the game files or your save.


2. KEYS
-------
  F9   (LB+RB+D-pad up)     phone on / off
  F10  (LB+RB+D-pad right)  next entry
  F11  (LB+RB+A)            take; during a job twice = cancel
  Arrow keys, Enter, Backspace while the phone is open.
  B                         answer a passenger's question (keyboard only; [Keys] ReplyKey)
  Change them in Pause > MODS > YOUR MODS > Horizon Transit.


3. PROBLEMS?
------------
Send Azimuth\TransportSim\logs\ (newest file) and fh2-mods\platform.log with an issue on GitHub.
