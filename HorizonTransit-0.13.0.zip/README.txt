HORIZON TRANSIT 0.13.0 - Rides and bus lines for Forza Horizon 2 (Azimuth)
==========================================================================================
Your festival. Your route.
One mod file, one phone (F9). Uber-style rides and bus lines with virtual passengers.

  - RIDES: like a driver app: press GO, requests come in one by one (accept or decline within
    20 s), GPS to pickup and destination, passengers who talk,
    remember you and rate your driving. VIPs, business clients, weddings, day trips.
  - DOORS: a door really opens and closes with its sound when passengers get in and out.
  - BUS: 6 lines both ways with real stops, a timetable and stop announcements.
  - PHONE OR TABLET: three devices (phone, Edge, tablet), 9 designs (new: Pure Dark).
  - COMPANY: reputation, shop, workday with a statement.
  - REAL CREDITS: every ride and bus line pays real game credits, and the shop (18 upgrades)
    takes them, through the game's own payout and spending. No mod money. Untested in game.
  - SOUND: speed warning tones, bus gong and stop bell, ride pings, payout chime.
  - TALK BACK: answer a passenger's question with B (keyboard) or LB+RB+D-pad down.
  - MAP: a dark map on the phone with the game's own roads, a preview of each ride and bus
    line before you take it. The mod builds it at start from your own game files (the pause
    menu's map picture and the game's road network); no extra file needed. A "Navi" zoom
    turns the map with your car, like the game's own navigation. Zooms glide, screens fade.
  - PHONE APP: Horizon Transit on your real Android phone. Rides, the map, bus lines, the
    passengers' chat, your account, the shop and all options; it takes the phone's design.
    Turn it on in the game phone: F9 > Options > "Connect phone app".
    During a job the map is right on top, as a plain map or a "Navi" that turns with your car.
    Without the game the app shows the last state; option changes reach the game when it runs again.

Source code: https://github.com/Flenkii/Horizon-Transit

No game files, no Azimuth, no FH2 Mod Platform and no FH2MP included. Never paste commands
into PowerShell to install a mod - anything like that is a scam.
Not supported by the FH2 Mod Platform author, the FH2MP team or the Azimuth developer.

Tested with: Azimuth 1.0.4, FH2 Mod Platform 2.9.0, FH2MP 1.4.1.


1. INSTALLATION
---------------
1. Install Azimuth and the FH2 Mod Platform (the FH2MP launcher brings it). Start the game once.
2. Copy the folder "fh2-mods" from this ZIP next to azimuth.exe:
     fh2-mods\TransportSim.dll   (all sounds are inside it)
3. With the FH2MP launcher: Pause > MODS > Installed mods > Horizon Transit >
   "Load when playing online" = On (FH2MP counts every start from its launcher as online).
4. Start the game, drive a few metres, press F9.

Phone app (optional):
5. Download HorizonTransit-0.13.0.apk from the same release page on your Android phone (7.0 or newer)
   and open it to install.
   Android asks once to allow installing from that source. A newer APK installs over the old
   one ("Update"); no need to uninstall, your connection is kept.
6. In the game: F9 > Options > "Connect phone app" > Enter. The row then shows a 4-digit
   pairing code and the PC's address (also in Pause > MODS > Horizon Transit > "Phone app"). Windows asks once whether the game may use the
   network: allow it for private networks.
7. Open the app on the phone (same Wi-Fi as the PC). It finds the PC; type the code. Done.
   No app? Any phone browser works too (also iPhone): http://<address>:8710
The app's map is drawn by your PC from your own game files; the app contains nothing of the game.

Door sounds: Sounds From The Lab (royalty-free). All other sounds are made by the mod's own script.

Uninstall: delete fh2-mods\TransportSim.dll (and the folder Azimuth\TransportSim if you like).
Horizon Transit never changes the game files. Since 0.13.0 it adds the credits you earn to your
save through the game itself, and the shop takes credits from it. The mod platform backs up
your save at every start (asked by the mod).


2. KEYS
-------
  F9   (LB+RB+D-pad up)     phone on / off
  F10  (LB+RB+D-pad right)  next entry
  F11  (LB+RB+A)            take; during a job twice = cancel
  Arrow keys, Enter, Backspace while the phone is open.
  B                         answer a passenger's question (keyboard only; [Keys] ReplyKey)
  Change them in Pause > MODS > YOUR MODS > Horizon Transit.


3. PROBLEMS?
------------
Send Azimuth\TransportSim\logs\ (newest file) and fh2-mods\platform.log with an issue on GitHub.
